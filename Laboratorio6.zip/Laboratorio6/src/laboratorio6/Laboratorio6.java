
package laboratorio6;



public class Laboratorio6 extends Thread {

    public Laboratorio6 (String str){
        super(str);  // se accede al constructor de la clase Thread para dar un nombre al hilo que se creará.
    }
    
    public void run(){
        for (int i = 0; i < 10; i++) {
            System.out.println(i + " "+ getName()); // retorna el nombre de los hilos
        }
        System.out.println("Ya terminé la ejecución del hilo"+ getName());
        
    }
    
    public static void main(String[] args) {
         Laboratorio6 primerHilo=new Laboratorio6("Ana");
        Laboratorio6 segundoHilo=new Laboratorio6("Juan");
        Laboratorio6 tercerHilo=new Laboratorio6("Pepe");
        
        primerHilo.start();
        segundoHilo.start();
        tercerHilo.start();
    }
}
    

