
package laboratorio6;
import java.awt.Image;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class Tragamonedas extends javax.swing.JFrame implements Runnable{
    Thread hilo1;
    Thread hilo2;
    Thread hilo3;
    Thread hilo4;
     boolean running = true;
    
int c1=0;int c2=0;int c3=0;int c4=0;

public void TM1(){
    Random random=new Random();
    int numero=random.nextInt(6)+1;
    
    switch(numero){
        case 1:
            ImageIcon icon1=new ImageIcon(getClass().getResource("/dados2/TM1.jpg"));
            Image image1=icon1.getImage();
            ImageIcon scaledIcon1= new ImageIcon(image1.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon1);
            c1=1;
            break;
        case 2:
             ImageIcon icon2=new ImageIcon(getClass().getResource("/dados2/TM2.jpg"));
            Image image2=icon2.getImage();
            ImageIcon scaledIcon2= new ImageIcon(image2.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon2);
            c1=2;
            break;
        case 3:
             ImageIcon icon3=new ImageIcon(getClass().getResource("/dados2/TM3.jpg"));
            Image image3=icon3.getImage();
            ImageIcon scaledIcon3= new ImageIcon(image3.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon3);
            c1=3;
            break;
        case 4: 
             ImageIcon icon4=new ImageIcon(getClass().getResource("/dados2/TM4.jpg"));
            Image image4=icon4.getImage();
            ImageIcon scaledIcon4= new ImageIcon(image4.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon4);
            c1=4;
            break;
        case 5:
             ImageIcon icon5=new ImageIcon(getClass().getResource("/dados2/TM5.jpg"));
            Image image5=icon5.getImage();
            ImageIcon scaledIcon5= new ImageIcon(image5.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon5);
            c1=5;
            break;
        case 6:
             ImageIcon icon6=new ImageIcon(getClass().getResource("/dados2/TM6.jpg"));
            Image image6=icon6.getImage();
            ImageIcon scaledIcon6= new ImageIcon(image6.getScaledInstance(jLabel1.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel1.setIcon(scaledIcon6);
            c1=6;
            break;
    }
    c1++;
}
public void TM2(){
    Random random=new Random();
    int numero=random.nextInt(6)+1;
    
    switch(numero){
        case 1:
            ImageIcon icon1=new ImageIcon(getClass().getResource("/dados2/TM1.jpg"));
            Image image1=icon1.getImage();
            ImageIcon scaledIcon1= new ImageIcon(image1.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon1);
            c2=1;
            break;
        case 2:
             ImageIcon icon2=new ImageIcon(getClass().getResource("/dados2/TM2.jpg"));
            Image image2=icon2.getImage();
            ImageIcon scaledIcon2= new ImageIcon(image2.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon2);
            c2=2;
            break;
        case 3:
             ImageIcon icon3=new ImageIcon(getClass().getResource("/dados2/TM3.jpg"));
            Image image3=icon3.getImage();
            ImageIcon scaledIcon3= new ImageIcon(image3.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon3);
            c2=3;
            break;
        case 4: 
             ImageIcon icon4=new ImageIcon(getClass().getResource("/dados2/TM4.jpg"));
            Image image4=icon4.getImage();
            ImageIcon scaledIcon4= new ImageIcon(image4.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon4);
            c2=4;
            break;
        case 5:
             ImageIcon icon5=new ImageIcon(getClass().getResource("/dados2/TM5.jpg"));
            Image image5=icon5.getImage();
            ImageIcon scaledIcon5= new ImageIcon(image5.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon5);
            c2=5;
            break;
        case 6:
             ImageIcon icon6=new ImageIcon(getClass().getResource("/dados2/TM6.jpg"));
            Image image6=icon6.getImage();
            ImageIcon scaledIcon6= new ImageIcon(image6.getScaledInstance(jLabel3.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel3.setIcon(scaledIcon6);
            c2=6;
            break;
    }
    c2++;
}
public void TM3(){
    Random random=new Random();
    int numero=random.nextInt(6)+1;
    
    switch(numero){
        case 1:
            ImageIcon icon1=new ImageIcon(getClass().getResource("/dados2/TM1.jpg"));
            Image image1=icon1.getImage();
            ImageIcon scaledIcon1= new ImageIcon(image1.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon1);
            c3=1;
            break;
        case 2:
             ImageIcon icon2=new ImageIcon(getClass().getResource("/dados2/TM2.jpg"));
            Image image2=icon2.getImage();
            ImageIcon scaledIcon2= new ImageIcon(image2.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon2);
            c3=2;
            break;
        case 3:
             ImageIcon icon3=new ImageIcon(getClass().getResource("/dados2/TM3.jpg"));
            Image image3=icon3.getImage();
            ImageIcon scaledIcon3= new ImageIcon(image3.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon3);
            c3=3;
            break;
        case 4: 
             ImageIcon icon4=new ImageIcon(getClass().getResource("/dados2/TM4.jpg"));
            Image image4=icon4.getImage();
            ImageIcon scaledIcon4= new ImageIcon(image4.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon4);
            c3=4;
            break;
        case 5:
             ImageIcon icon5=new ImageIcon(getClass().getResource("/dados2/TM5.jpg"));
            Image image5=icon5.getImage();
            ImageIcon scaledIcon5= new ImageIcon(image5.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon5);
            c3=5;
            break;
        case 6:
             ImageIcon icon6=new ImageIcon(getClass().getResource("/dados2/TM6.jpg"));
            Image image6=icon6.getImage();
            ImageIcon scaledIcon6= new ImageIcon(image6.getScaledInstance(jLabel4.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel4.setIcon(scaledIcon6);
            c3=6;
            break;
    }
    c3++;
}
public void TM4(){
    Random random=new Random();
    int numero=random.nextInt(6)+1;
    
    switch(numero){
        case 1:
            ImageIcon icon1=new ImageIcon(getClass().getResource("/dados2/TM1.jpg"));
            Image image1=icon1.getImage();
            ImageIcon scaledIcon1= new ImageIcon(image1.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon1);
            c4=1;
            break;
        case 2:
             ImageIcon icon2=new ImageIcon(getClass().getResource("/dados2/TM2.jpg"));
            Image image2=icon2.getImage();
            ImageIcon scaledIcon2= new ImageIcon(image2.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon2);
            c4=2;
            break;
        case 3:
             ImageIcon icon3=new ImageIcon(getClass().getResource("/dados2/TM3.jpg"));
            Image image3=icon3.getImage();
            ImageIcon scaledIcon3= new ImageIcon(image3.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon3);
            c4=3;
            break;
        case 4: 
             ImageIcon icon4=new ImageIcon(getClass().getResource("/dados2/TM4.jpg"));
            Image image4=icon4.getImage();
            ImageIcon scaledIcon4= new ImageIcon(image4.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon4);
            c4=4;
            break;
        case 5:
             ImageIcon icon5=new ImageIcon(getClass().getResource("/dados2/TM5.jpg"));
            Image image5=icon5.getImage();
            ImageIcon scaledIcon5= new ImageIcon(image5.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon5);
            c4=5;
            break;
        case 6:
             ImageIcon icon6=new ImageIcon(getClass().getResource("/dados2/TM6.jpg"));
            Image image6=icon6.getImage();
            ImageIcon scaledIcon6= new ImageIcon(image6.getScaledInstance(jLabel5.getWidth(),jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
            jLabel5.setIcon(scaledIcon6);
            c4=6;
            break;
    }
    c4++;
}
    public void run(){
    Thread temporal=Thread.currentThread(); // se almacena el hilo que se esté ejecutando
    
   
        while (temporal == hilo1 && running) {
            TM1();
            try {
                Thread.sleep(100); // Pausa de 100 milisegundos (puedes ajustar la velocidad aquí)
            } catch (InterruptedException ex) {
                Logger.getLogger(Tiradados.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        while (temporal == hilo2 && running) {
            TM2();
            try {
                Thread.sleep(100); // Pausa de 100 milisegundos (puedes ajustar la velocidad aquí)
            } catch (InterruptedException ex) {
                Logger.getLogger(Tiradados.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         while (temporal == hilo3 && running) {
            TM3();
            try {
                Thread.sleep(100); // Pausa de 100 milisegundos (puedes ajustar la velocidad aquí)
            } catch (InterruptedException ex) {
                Logger.getLogger(Tiradados.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
          while (temporal == hilo4 && running) {
            TM4();
            try {
                Thread.sleep(100); // Pausa de 100 milisegundos (puedes ajustar la velocidad aquí)
            } catch (InterruptedException ex) {
                Logger.getLogger(Tiradados.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
    
        
   // while(temporal==hilo2)
  //  {
        //corredor2();
        //System.out.println("soy hilo 2  "+ c2);
   // }
    
        
    
} 
    public Tragamonedas() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 102, 102));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("INICIAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("PARAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel6.setText("TRAGAMONEDAS");

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Volver al menu");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(121, 121, 121)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jButton1)
                        .addGap(123, 123, 123)
                        .addComponent(jButton2)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jButton3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          hilo1= new Thread(this);//instanciados
          hilo2= new Thread(this);
          hilo3= new Thread(this);
          hilo4= new Thread(this);
          
          running = true;
         hilo1.start();
         hilo2.start();
         hilo3.start();
         hilo4.start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            running = false;
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Menu a=new Menu();
        a.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tragamonedas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
